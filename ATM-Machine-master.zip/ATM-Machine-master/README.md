# ATM-Machine
This Project is to make an Automated Teller Machine with user's Account Number,Password,and bank account.Using this data,users can withdraw, deposit, and view their account balance.

To run the project\
1.Download all the code files (total 3)\
2.Store them in a single folder\
3.Either use your Java IDE e.g. Eclipse ,InteliJ or NetBeans\
4.Or in Windows open command prompt and go to project Directory\
5. run command : javac ATM.java\
6. After completion your folder will contain 3 .class files\
7. In command prompt run command: java ATM\
8. Project will start running
